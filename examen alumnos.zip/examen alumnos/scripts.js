function counter(){
    var c = 3;

    document.getElementById("imgc").onclick = function add(){
        document.getElementById("counterp").innerHTML = 
        document.getElementById("counterp").innerHTML + 
        "El texto de este artículo tiene "+c+" parágrafos, y ahora con este son "+ (c+1)+"<br>";
        
        c++;
    }
    
}